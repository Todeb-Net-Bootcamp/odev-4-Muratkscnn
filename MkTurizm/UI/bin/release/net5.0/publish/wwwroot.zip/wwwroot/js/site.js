﻿
$(".seats").click(function () {
    alert("2")
})